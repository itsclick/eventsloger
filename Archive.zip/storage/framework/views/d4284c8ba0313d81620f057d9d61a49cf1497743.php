<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Membership Management System</title>

        <!-- Fonts -->
        <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
            <!-- App favicon -->
            <link src="<?php echo e(asset('assets/images/favicon.ico')); ?>" rel="stylesheet">
            <!-- App css -->
            
            <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendors.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset ('assets/plugins/jsvectormap/jsvectormap.min.css')); ?>"  />
            <link rel="stylesheet" href="<?php echo e(asset ('assets/plugins/spinkit/spinkit.min.css')); ?>"  />


           

            
            

           


           
            

            

           
        <!-- Styles -->
        
        <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/vendors.min.js')); ?>"></script>
          <script src="<?php echo e(asset('assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/plugins/jsvectormap/jsvectormap.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/maps/us-aea-en.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/maps/us-lcc-en.js')); ?>"></script>
           <script src="<?php echo e(asset('assets/js/maps/us-mill-en.js')); ?>"></script>
           <script src="<?php echo e(asset('assets/js/pages/custom-table.js')); ?>"></script>
           <script src="<?php echo e(asset('assets/js/pages/dashboard.js')); ?>"></script>
           <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>


          



           







     


    <!-- Apex Charts js -->
  

    <!-- Vector Map Js -->
  
    
    

    <!-- Custom table -->
    

    <!-- Dashboard js -->
    
        



        







        
       


        
        


      












        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
       <div id="app"></div>

       <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

       
        </div>
    </body>
</html>
<?php /**PATH /Users/ibob/Documents/Laraval/eventsloger/resources/views/welcome.blade.php ENDPATH**/ ?>