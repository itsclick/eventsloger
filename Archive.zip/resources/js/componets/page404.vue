<template>


    
    404 page
    </template> 
    
    
    
    <script setup>
    </script>
    
    
    
    <style lang="css" scoped>
    
    </style>