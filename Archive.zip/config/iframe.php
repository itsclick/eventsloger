<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Allowed domains that can embed public forms
    |--------------------------------------------------------------------------
    */

    'allowed_domains' => [
        'https://ipay.obige.org',
        'https://obige.org',
    ],

];
